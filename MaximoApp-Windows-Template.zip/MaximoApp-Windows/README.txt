MAXIMO APPLICATION FOR WINDOWS
===============================

SETUP:
1. Edit .env file with your Maximo server details
2. Double-click run_maximo.bat to start the application
3. Application will open in your web browser

ALTERNATIVE:
- You can also double-click MaximoApp.exe directly

REQUIREMENTS:
- No additional software needed
- All dependencies included

TROUBLESHOOTING:
- If Windows Defender blocks the app, click "More info" then "Run anyway"
- Check .env file if connection fails
- Ensure Maximo server is accessible

SUPPORT:
- Keep this window open while using the application
- Close this window to stop the application
